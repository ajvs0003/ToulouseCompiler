/****************************************************************************
** Meta object code from reading C++ file 'tableUniforms.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../tableUniforms.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QVector>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tableUniforms.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_tableUniforms_t {
    QByteArrayData data[16];
    char stringdata0[211];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_tableUniforms_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_tableUniforms_t qt_meta_stringdata_tableUniforms = {
    {
QT_MOC_LITERAL(0, 0, 13), // "tableUniforms"
QT_MOC_LITERAL(1, 14, 11), // "addUniforms"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 23), // "QVector<dataForUniform>"
QT_MOC_LITERAL(4, 51, 4), // "data"
QT_MOC_LITERAL(5, 56, 24), // "handleButtonAboutUniform"
QT_MOC_LITERAL(6, 81, 18), // "handleButtonAccept"
QT_MOC_LITERAL(7, 100, 22), // "handleButtonAddUniform"
QT_MOC_LITERAL(8, 123, 10), // "handleData"
QT_MOC_LITERAL(9, 134, 14), // "dataForUniform"
QT_MOC_LITERAL(10, 149, 8), // "editSlot"
QT_MOC_LITERAL(11, 158, 3), // "row"
QT_MOC_LITERAL(12, 162, 3), // "col"
QT_MOC_LITERAL(13, 166, 14), // "cell_onClicked"
QT_MOC_LITERAL(14, 181, 20), // "cell_comboBoxChanged"
QT_MOC_LITERAL(15, 202, 8) // "newValue"

    },
    "tableUniforms\0addUniforms\0\0"
    "QVector<dataForUniform>\0data\0"
    "handleButtonAboutUniform\0handleButtonAccept\0"
    "handleButtonAddUniform\0handleData\0"
    "dataForUniform\0editSlot\0row\0col\0"
    "cell_onClicked\0cell_comboBoxChanged\0"
    "newValue"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_tableUniforms[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   54,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    0,   57,    2, 0x08 /* Private */,
       6,    0,   58,    2, 0x08 /* Private */,
       7,    0,   59,    2, 0x08 /* Private */,
       8,    1,   60,    2, 0x08 /* Private */,
      10,    2,   63,    2, 0x08 /* Private */,
      13,    0,   68,    2, 0x08 /* Private */,
      14,    1,   69,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,    4,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   11,   12,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   15,

       0        // eod
};

void tableUniforms::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<tableUniforms *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->addUniforms((*reinterpret_cast< const QVector<dataForUniform>(*)>(_a[1]))); break;
        case 1: _t->handleButtonAboutUniform(); break;
        case 2: _t->handleButtonAccept(); break;
        case 3: _t->handleButtonAddUniform(); break;
        case 4: _t->handleData((*reinterpret_cast< const dataForUniform(*)>(_a[1]))); break;
        case 5: _t->editSlot((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 6: _t->cell_onClicked(); break;
        case 7: _t->cell_comboBoxChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QVector<dataForUniform> >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< dataForUniform >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (tableUniforms::*)(const QVector<dataForUniform> & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&tableUniforms::addUniforms)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject tableUniforms::staticMetaObject = { {
    &QDialog::staticMetaObject,
    qt_meta_stringdata_tableUniforms.data,
    qt_meta_data_tableUniforms,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *tableUniforms::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *tableUniforms::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_tableUniforms.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int tableUniforms::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void tableUniforms::addUniforms(const QVector<dataForUniform> & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
